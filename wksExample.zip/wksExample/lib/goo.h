/*
 * =====================================================================================
 *
 *       Filename:  foo.h
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  10/11/07 12:41:52 GMT
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  first_name last_name (fl), fl@my-company.com
 *        Company:  my-company
 *
 * =====================================================================================
 */

void goo();



